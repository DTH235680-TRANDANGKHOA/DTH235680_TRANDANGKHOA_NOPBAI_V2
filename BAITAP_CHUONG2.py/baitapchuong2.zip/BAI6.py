print('Câu 4: Python hỗ trợ những kiểu dữ liệu cơ bản nào?')
print('Trả lời: Kiểu dữ liệu cơ bản trong Python gồm: int, float, complex, str, bool, list, tuple, set, dict')